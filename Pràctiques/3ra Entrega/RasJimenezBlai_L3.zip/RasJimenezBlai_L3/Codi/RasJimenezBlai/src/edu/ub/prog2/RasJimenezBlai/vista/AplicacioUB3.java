/*
 * @author Blai Ras Jimenez
 * Data: 20 de Febrer de 2016
 */

// Imports necesaris:
package edu.ub.prog2.RasJimenezBlai.vista;

import edu.ub.prog2.RasJimenezBlai.controlador.Controlador;
import edu.ub.prog2.RasJimenezBlai.model.CarpetaFitxers;
import edu.ub.prog2.RasJimenezBlai.model.FitxerMultimedia;
import edu.ub.prog2.utils.AplicacioException;
import edu.ub.prog2.utils.InFileFolder;
import edu.ub.prog2.utils.Menu;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;






public class AplicacioUB3 {
    
    Scanner sc = new Scanner(System.in);

    
    //Menu 1
    static private enum OpcionsMenuPrincipal{MENU_PRINCIPAL_GestioBib, MENU_PRINCIPAL_GestioAlbums, MENU_PRINCIPAL_ControlReproduccio, MENU_PRINCIPAL_GuardarDades, MENU_PRINCIPAL_RecuperarDades, MENU_PRINCIPAL_SORTIR}
    //Submenu 1
    static private enum OpcionsSubmenu1 {AfegirFitxerBib,MostrarBib,EliminarFitxer,MenuAnterior1};
    //Submenu 1.1
    static private enum OpcionsSubmenu11 {AfegirVideo, AfegirAudio, AfegirImatge, MenuAnterior11};
    //Submenu 2
    static private enum OpcionsSubmenu2 {AfegirAlbum, MostrarAlbum, EliminarAlbum, GestionarAlbum, MenuAnterior2};
    //Submenu 2.2
    static private enum OpcionsSubmenu22 {AfegirFitxMulti, MostrarAlbum, EliminarFitxMulti, CanviarTitol, CanviarMidaMaxima, MenuAnterior22};
    
    static private enum OpcionsSubmenu3 {ReproduirFitxRepro, VisualitzaImatge, ReproduirBib, ReproduirAlb, ReproCiclica, DesactivarPremium, GestioReproduccio, MenuAnterior3};
    
    static private enum OpcionsSubmenu33 {Rempren, Pausa, Atura, Salta, Sortir};
    
    //Descripcions dels Menus
    static private String[] descMenuPrincipal ={"Gestio Biblioteca", "Gestio Albums", "Control Reproduccio/Visio", "Guardar Dades", "Recuperar Dades","Surt de l'aplicació"};
    static private String[] descSubMenu1 ={"Afegir fitxer Multimedia a la Biblioteca", "Mostrar Biblioteca", "Eliminar Fitxer Multimedia", "Menu Anterior"};
    static private String[] descSubMenu11 ={"Afegir Video", "Afegir audio","Afegir Imatge", "Menu Anterior"};
    static private String[] descSubMenu2 ={"Afegir Album", "Mostrar Albums", "Eliminar Album", "Gestionar Album", "Menu Anterior"};
    static private String[] descSubMenu22 ={"Afegir Fitxer Multimedia", "Mostrar Album", "Eliminar Fitxer Multimedia", "Canviar Titol", "Canviar Mida Maxima", "Menu Anterior"};
    static private String[] descSubMenu3 = {"Reproduir un fitxer Reproduible", "Visualitza una imatge", "Reproduir tota la biblioteca", "Reproduir un Album", "Activar/desactivar reproducció cíclica", "Desactivar reproducció Premium", "Gestió reproducció en curs", "Menu Anterior"};  
    static private String[] descSubMenu33 = {"Re-empren", "Pausa", "Atura", "Salta", "Sortir"};
    
    //Taula de fitxers
    InFileFolder taula;
    Controlador controlador = new Controlador();
    //Controlador
    
    // Constructor:
    public AplicacioUB3() { 
            taula = new CarpetaFitxers();
    }
    
    

        
    public void gestioAplicacioUB(){
        
        //Creem l'objecte pel Menú. Li passem com a parametre el nom del menú
        Scanner sc;
        sc=new Scanner(System.in);


        
        //Creem l'objecte pel Menú. Li passem com a parametre el nom del menú
        Menu<OpcionsMenuPrincipal> menu = new Menu<OpcionsMenuPrincipal>("Menu Principal", OpcionsMenuPrincipal.values());
        
        //Decripció de les opcions
        menu.setDescripcions(descMenuPrincipal);
        
        //Obtenim una opció des del menú i accionala
        
        OpcionsMenuPrincipal opcio = null; //Inicialitzo opcio
        do {
            //MOstrem opcions
            menu.mostrarMenu();
            //Demana una opcio
            opcio = menu.getOpcio(sc);
            

            
            //Fem les accions
            switch(opcio) {
                
                
                case MENU_PRINCIPAL_GestioBib: //Opció d'afegir un fitxer
                    System.out.println("Has triat Afegir Fitxer");
                    gestioMenuSecundari1(sc);
                    break;
                    
                case MENU_PRINCIPAL_GestioAlbums: //Opcio d'eliminar un fitxer
                    System.out.println("Has triat gestionar els Albums");
                    gestioMenuSecundari2(sc);
                    break;
                    
                case MENU_PRINCIPAL_ControlReproduccio:
                    gestioMenuSecundari3(sc);
                    break;
                    
                case MENU_PRINCIPAL_GuardarDades:
                    System.out.println("Has triat Guadar la Carpeta");
                    FitxerMultimedia fitxer;
                    String path;
                    System.out.println("Dona'm el cami del fitxer a guardar");
                    path = sc.nextLine();
                    try {
                        controlador.guardarDadesDisc(path);
                    } catch (AplicacioException ex) {
                        System.out.println("No s'ha pogut guardar la carpeta\n" + ex.getMessage());
                    }
                    break;
                    
                case MENU_PRINCIPAL_RecuperarDades:
                    System.out.println("Has triar recuperar carpeta");
                    String camiRecuperar;
                    System.out.println("A on has guardat la carpeta?");
                    camiRecuperar = sc.nextLine();
                    try {
                        controlador.carregarDadesDisc(camiRecuperar);
                    } catch (AplicacioException ex) {
                        System.out.println("La carpeta no ha pogut ser recuperada \n " +ex.getMessage());
                    }
                    System.out.println("Carpeta recuperada amb èxit!");
                    break;
                    
                case MENU_PRINCIPAL_SORTIR:
                    System.out.println("Fins aviat!");
                    break;
            }
        } while (opcio!=OpcionsMenuPrincipal.MENU_PRINCIPAL_SORTIR);
    }
    
    
        
        /**
     * Menú secundari
     * @param sc Objecte de tipus Scanner que permet accedir al teclat
     */
    private void gestioMenuSecundari1(Scanner sc) {
        

        // Creem l'objecte per al menú. Li passem com a primer paràmetre el nom del menú
        Menu<OpcionsSubmenu1> menu=new Menu<OpcionsSubmenu1>("Menu Secundari",OpcionsSubmenu1.values());
            
            
        // Assignem la descripció de les opcions
        menu.setDescripcions(descSubMenu1);
            
        // Obtenim una opció des del menú i fem les accions pertinents
            OpcionsSubmenu1 opcio = null;
        do {
            // Mostrem les opcions del menú
            menu.mostrarMenu();

            // Demanem una opcio
            opcio=menu.getOpcio(sc);
            
            // Fem les accions necessàries
            switch(opcio) {
                case AfegirFitxerBib:
                    // Mostrem un missatge indicant que s'ha triat aquesta opció
                    System.out.println("Has triat afegir un fitxer");
                    gestioMenuSecundari11(sc);
                    break;
                    
                case MostrarBib:
                    System.out.println("Biblioteca:");
                    imprimir(controlador.mostrarBiblioteca());
                    break;
                    
                case MenuAnterior1:
                    break;
            }

        } while(opcio!=OpcionsSubmenu1.MenuAnterior1);
    }
    
    private void gestioMenuSecundari11(Scanner sc) {
        Menu<OpcionsSubmenu11> menu11 = new Menu<OpcionsSubmenu11>("Menu Secundari 1.1",OpcionsSubmenu11.values());
        menu11.setDescripcions(descSubMenu11);
        OpcionsSubmenu11 opcio = null;
            do {
            // Mostrem les opcions del menú
                menu11.mostrarMenu();

            // Demanem una opcio
                opcio=menu11.getOpcio(sc);
      
            // Fem les accions necessàries
                switch(opcio) {
                    case AfegirVideo:
                        afegirVideo();
                        break;
                        
                    case AfegirAudio:
                        afegirAudio();
                        break;
                        
                    case AfegirImatge:
                        afegirImatge();
                        break;
                    case MenuAnterior11:
                        break;
                }

        } while(opcio!=OpcionsSubmenu11.MenuAnterior11);
    }
    
    private void gestioMenuSecundari2(Scanner sc){
        Menu<OpcionsSubmenu2> menu2 = new Menu<OpcionsSubmenu2>("Menu Secundari 2",OpcionsSubmenu2.values());
        menu2.setDescripcions(descSubMenu2);
        OpcionsSubmenu2 opcio = null;
            do {
            // Mostrem les opcions del menú
                menu2.mostrarMenu();

            // Demanem una opcio
                opcio=menu2.getOpcio(sc);
                
            //ArrayList per imprimir
            
            ArrayList<String> imp = new ArrayList();
            int posicio=1;
            String titol;
            // Fem les accions necessàries
                switch(opcio) {
                    case AfegirAlbum:
                        afegirAlbum();
                        break;
                        
                    case MostrarAlbum:
                    // Mostrem un missatge indicant que s'ha triat aquesta opció
                        System.out.println("Albums:");
                        imprimir(controlador.mostrarLlistatAlbums());
                        break;
                        
                    case EliminarAlbum:
                        System.out.println("Has triat suprimir un Album");
                        eliminarAlbum();
                        break;
                        
                    case GestionarAlbum:
                        System.out.println("Has triat gestionar un Album");
                        gestioMenuSecundari22(sc);
                        break;
                        
                    case MenuAnterior2:
                        break;
                }
        } while(opcio!=OpcionsSubmenu2.MenuAnterior2);
    }
    
    private void gestioMenuSecundari22(Scanner sc) {
        Menu<OpcionsSubmenu22> menu22 = new Menu<OpcionsSubmenu22>("Menu Secundari 2.2",OpcionsSubmenu22.values());
        menu22.setDescripcions(descSubMenu22);
        OpcionsSubmenu22 opcio = null;
            do {
            // Mostrem les opcions del menú
                menu22.mostrarMenu();

            // Demanem una opcio
                opcio=menu22.getOpcio(sc);
                
                
            // Fem les accions necessàries
                switch(opcio) {
                    case AfegirFitxMulti:
                        afegirFitxerMultimedia();
                        break;
                        
                    case MostrarAlbum:
                        System.out.println("Tria l'album a mostrar");
                        String titolMostrar;
                        imprimir(controlador.mostrarLlistatAlbums());
                        try {
                            titolMostrar = sc.nextLine();
                            imprimir(controlador.mostrarAlbum(titolMostrar));
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut mostrar l'Album " +ex.getMessage());
                        }
                        break;
                        
                    case EliminarFitxMulti:
                        System.out.println("Has triat suprimir un Fitxer Multimedia");
                        int i;
                        System.out.println("Indicam la posició del fitxer que vols eliminar");
                        imprimir(controlador.mostrarBiblioteca());
                        i = sc.nextInt();
                        try {
                            controlador.esborrarFitxer(i);
                        } catch (AplicacioException ex) {
                            System.out.println("Alguna cosa ha anat malament" + ex.getMessage());
                        }
                        break;
                        
                    case CanviarTitol:
                        canviarTitol();
                        break;
                        
                    case CanviarMidaMaxima:
                        canviarMidaMax();
                        break;
                    case MenuAnterior22:
                        break;
                }
        } while(opcio!=OpcionsSubmenu22.MenuAnterior22);
    }
    
    public void gestioMenuSecundari3(Scanner sc) {
        Menu<OpcionsSubmenu3> menu3 = new Menu<OpcionsSubmenu3>("Menu Secundari 3",OpcionsSubmenu3.values());
        menu3.setDescripcions(descSubMenu3);
        OpcionsSubmenu3 opcio = null;
        do {
            // Mostrem les opcions del menú
                menu3.mostrarMenu();

            // Demanem una opcio
                opcio=menu3.getOpcio(sc);
                
                
            // Fem les accions necessàries
                switch(opcio) {
                    case ReproduirFitxRepro:
                        int fitxer;
                        System.out.println("Selecciona el fitxer de la biblioteca a reproduir:");
                        imprimir(controlador.mostrarBiblioteca());
                        fitxer = sc.nextInt();
                        try {
                            controlador.reproduirFitxer(fitxer);
                        } catch (AplicacioException ex) {
                            System.out.println("Alguna cosa ha anat malament:" + ex.getMessage());
                        }
                        break;
                        
                    case VisualitzaImatge:
                        System.out.println("Quina imatge vols visualitzar?");
                        imprimir(controlador.mostrarBiblioteca());
                        int imatge = sc.nextInt();
                        try {
                            controlador.mostrarFitxer(imatge, -1);
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut mostrar la imatge!"+ex.getMessage());
                        }
                        break;
                        
                    case ReproduirBib:
                        try {
                            controlador.reproduirCarpeta();
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut reproduir la carpeta"+ex.getMessage());
                        }
                        break;
                        
                    case ReproduirAlb:
                        System.out.println("Digue'm el titol del album a reproduir:");
                        imprimir(controlador.mostrarLlistatAlbums());
                        String titol = sc.nextLine();
                        try {
                            controlador.reproduirCarpeta(titol);
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut reproduir l'album"+ex.getMessage());
                        }
                        
                        break;
                    case ReproCiclica:
                        reproCiclica();
                        break;
                        
                    case DesactivarPremium:
                        controlador.desactivarModePremium();
                        break;
                        
                    case GestioReproduccio:
                        gestioMenuSecundari33(sc);
                        break;
                        
                    case MenuAnterior3:
                        try {
                            controlador.tancarFinestraReproductor();
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut tancar la finestra"+ex.getMessage());
                        }
                        break;
                }
        } while(opcio!=OpcionsSubmenu3.MenuAnterior3);
      
    }
    
    public void gestioMenuSecundari33(Scanner sc) {
        Menu<OpcionsSubmenu33> menu33 = new Menu<OpcionsSubmenu33>("Menu Secundari 3",OpcionsSubmenu33.values());
        menu33.setDescripcions(descSubMenu3);
        OpcionsSubmenu33 opcio = null;
        do {
            // Mostrem les opcions del menú
                menu33.mostrarMenu();

            // Demanem una opcio
                opcio=menu33.getOpcio(sc);
                
                
            // Fem les accions necessàries
                switch(opcio) {
                    case Rempren:
                        controlador.reemprenReproduccio();
                        break;
                        
                    case Pausa:
                        try {
                            controlador.pausaReproduccio();
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut pausar la reproduccio!"+ex.getMessage());
                        }
                        break;
                        
                    case Atura:
                        try {
                            controlador.aturaReproduccio();
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut aturar la reproduccio!"+ex.getMessage());
                        }
                        break;
                        
                    case Salta:
                        try {
                            controlador.saltaReproduccio();
                        } catch (AplicacioException ex) {
                            System.out.println("No s'ha pogut reproduir el seguent fitxer!"+ex.getMessage());
                        }
                        break;
                        
                    case Sortir:
                        break;
                }
        } while (opcio != OpcionsSubmenu33.Sortir);
    }
       
                
    
    private void imprimir(List<String> llista) {
        Iterator itr = llista.iterator();
        int pos = 1;
        while (itr.hasNext()) {
            System.out.println(pos + ":" + itr.next());
            pos++;
        }
        
    }
    
    private void afegirVideo() {
        int alcada, amplada;
        float durada;
        String cami, nom,codec;
        float fps;
        
        System.out.println("Has triat Afegir un Video");
        System.out.println("On es troba el Video?");
        cami = sc.nextLine();
        System.out.println("Quin nom te?");
        nom = sc.nextLine();
        System.out.println("Diguem el seu codec");
        codec = sc.nextLine();
        System.out.println("Diguem la seva durada");
        durada = sc.nextFloat();
        System.out.println("Diguem la seva alcada");
        alcada = sc.nextInt();
        System.out.println("Diguem ara la seva amplada");
        amplada = sc.nextInt();
        System.out.println("Diguem els seus fps");
        fps = sc.nextFloat();

        try {
            controlador.afegirVideo(cami, nom, codec, durada, alcada, amplada, fps);
        } catch (AplicacioException ex) {
            System.out.println("No s'ha pogut afegir el Video "+ ex.getMessage());
        }
    }

    
    private void afegirAudio() {
        float durada;
        String cami, nom,codec;
        Scanner sc = new Scanner(System.in);
        System.out.println("Has triat afegir Audio");
        String camiImatge;
        int kpbs;
        System.out.println("Diguem el cami on es troba l'Audio");
        cami = sc.nextLine();
        System.out.println("Diguem on es troba la imatge del Audio");
        camiImatge = sc.nextLine();
        System.out.println("Diguem el nom del Audio");
        nom = sc.nextLine();
        System.out.println("Diguem el codec del Audio");
        codec = sc.nextLine();
        System.out.println("Diguem la durada del Audio");
        durada = sc.nextFloat();
        System.out.println("Diguem els kilobytes per segon del Audio");
        kpbs = sc.nextInt();
        try {
            controlador.afegirAudio(cami, camiImatge, nom, codec, durada, kpbs);
        } catch (AplicacioException ex) {
            System.out.println("No s'ha pogut afegir l'Audio" + ex.getMessage());
        }
    }
    
    private void afegirImatge() {
        int alcada, amplada;
        String cami,nom,titol;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("On esta la imatge a inserir?");
        cami = sc.nextLine();
        System.out.println("Quin nom te?");
        nom = sc.nextLine();
        System.out.println("Quina alcada te la imatge?");
        alcada = sc.nextInt();
        System.out.println("Quina amplada te?");
        amplada = sc.nextInt();
        try {
            controlador.afegirImatge(cami, nom, alcada, amplada);
        } catch (AplicacioException ex) {
            System.out.println("No s'ha pogut afegir la imatge!"+ex.getMessage());
        }
    }
    
    private void afegirAlbum() {
        String titol;
        ArrayList<String> imp = new ArrayList();
        int posicio=1;
        
        System.out.println("Has triat afegir un Album");
        System.out.println("Digue'm el titol del album que desitjes");
        titol = sc.nextLine();
        try {
            controlador.afegirAlbum(titol);
        } catch (AplicacioException error) {
            System.out.println("Album no afegit correctament!" +error.getMessage());
        }
        
    }
    
    private void eliminarAlbum() {
        String titol;
        System.out.println("Introdueix el titol del album");
        imprimir(controlador.mostrarLlistatAlbums());
        titol = sc.nextLine();
        try {
            controlador.esborrarAlbum(titol);
        } catch(AplicacioException ex) {
            System.out.println("Error al elimnar un àlbum: " +ex.getMessage());
        }
    }
    
    private void afegirFitxerMultimedia() {
        System.out.println("Has triat afegir un Fitxer Multimedia");
        System.out.println("Indiquem el títol del Album on vols afegir el fitxer");
        imprimir(controlador.mostrarLlistatAlbums());
        String album = sc.nextLine();
        imprimir(controlador.mostrarBiblioteca());
        System.out.println("Indicam el número del fitxer que vols afegir");
        int posicio;
        posicio = sc.nextInt();
        try {
            controlador.afegirFitxer(album, posicio);
        } catch (AplicacioException ex) {
            System.out.println("No s'ha pogut afegir el fitxer amb èxit");
        }
    }
    
    private void canviarTitol() {
        String titolVell;
        System.out.println("Has triat Canviar un Titol");

        imprimir(controlador.mostrarLlistatAlbums());


        System.out.println("Introdueix el titol del Album a canviar el nom");
        titolVell = sc.nextLine();
        String titolNou;
        System.out.println("Ara digue'm el titol desitjat");
        titolNou = sc.nextLine();
        try {
            controlador.canviarTitolAlbum(titolVell, titolNou);
        } catch (AplicacioException ex) {
            System.out.println("No s'ha pogut canviar el titol\n " + ex.getMessage());
        }
    }
    
    private void canviarMidaMax() {
        String titolMida;
        int mida;
        System.out.println("Has triat canviar la mida d'un Album");
        System.out.println("Tria el titol del album a canviar la mida: ");
        imprimir(controlador.mostrarLlistatAlbums());

        titolMida = sc.nextLine();

        System.out.println("Ara digue'm la nova mida del album");
        mida = sc.nextInt();
        try {
            controlador.canviarMidaAlbum(titolMida, mida);
        }catch (AplicacioException ex) {
            System.out.println("No s'ha pogut canviar la mida del Album!");
        }
    }
    
    private void reproCiclica() {
        if (controlador.getCiclic()) {
        System.out.println("Actualment la Reproduccio Ciclica esta activada. Desactivant...");
        controlador.activarModeCiclic(false);
        } else {
            System.out.println("Actualment la Reproduccio Ciclica esta desactivada. Activant...");
            controlador.activarModeCiclic(true);
        }
    }
    
    
    
}

