/*
 *
 * @author Blai Ras
 * Data: 9 de Febrer de 2016
 */
package edu.ub.prog2.RasJimenezBlai.vista;

import java.util.Scanner;


public class InciadorAplicacioUB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        AplicacioUB3 aplicacio = new AplicacioUB3(); //Crea el reproductor
        
        aplicacio.gestioAplicacioUB(); //Administra el reproductor
        
    }
    
}
